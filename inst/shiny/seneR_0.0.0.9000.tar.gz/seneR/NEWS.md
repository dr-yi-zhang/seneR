# seneR (development version)

* Initial CRAN submission.
